#!/usr/bin/env python
# coding: utf-8

# # Q1. Maximum Product of Two Elements in an Array

# In[ ]:


class Solution(object):
    def maxProduct(self, nums):
        a = b = 0
        for num in nums:
            if num > a:
                a, b = num, a
            elif num > b:
                b = num
        return (a-1)*(b-1)


# # Q2. Count Number of Teams

# In[ ]:


class Solution:
    def numTeams(self, rating: List[int]) -> int:
        res = 0
        for i in range(1, len(rating)-1):
            less, greater = [0]*2, [0]*2
            for j in range(len(rating)):
                if rating[i] > rating[j]:
                    less[i < j] += 1
                if rating[i] < rating[j]:
                    greater[i < j] += 1
            res += less[0]*greater[1] + greater[0]*less[1]
        return res


# # Q3. Number of Students Doing Homework at a Given Time

# In[ ]:


class Solution:
    def busyStudent(self, startTime: List[int], endTime: List[int], queryTime: int) -> int:
        ans=0
        m=zip(startTime, endTime)
        for s, e in m:
            if s<=queryTime<=e:
                ans+=1
        return ans
        


# # Q4. Number of Steps to Reduce a Number to Zero

# In[ ]:


class Solution:
    def numberOfSteps (self, num: int) -> int:
        ans = 0
        while num > 0:
            if num % 2: num -= 1
            else: num /= 2
            ans += 1
        return ans


# # Q5. Counting Bits

# In[ ]:


class Solution(object):
    def countBits(self, num):
        res = [0]
        for i in xrange(1, num + 1):
            # Number of 1's in i = (i & 1) + number of 1's in (i / 2).
            res.append((i & 1) + res[i >> 1])
        return res
    
    def countBits2(self, num):
        s = [0]
        while len(s) <= num:
            s.extend(map(lambda x: x + 1, s))
        return s[:num + 1]

